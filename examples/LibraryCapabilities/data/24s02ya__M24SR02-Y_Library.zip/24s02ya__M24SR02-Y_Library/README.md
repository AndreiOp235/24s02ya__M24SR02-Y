# 24s02ya__M24SR02-Y_Library
 Arduino library written in an attempt to revive a NFC module salvaged from a Candy washing machine
